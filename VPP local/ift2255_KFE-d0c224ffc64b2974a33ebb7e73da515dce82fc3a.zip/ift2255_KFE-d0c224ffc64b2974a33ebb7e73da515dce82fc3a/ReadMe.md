
<!--- inspirer de https://gist.githubusercontent.com/JulienRAVIA/1cc6589cbf880d380a5bb574baa38811/raw/4b124956b45d4bdacf338da137e9c53b392f1560/README-Template.md) --->

# Outil BINECO
![Echeancier](/images/echeancier.JPG )

**POUR EXECUTER L'APPLICATION SIMPLEMENT RUN LA FONCITON MAIN!**
___ 
## Site mapping
![](images\pageAccueil.jpg)
![](images\menuConsommateur.jpg)
![](images\menuResident.jpg)

----
## Instructions
*Comme seul le nom d’utilisateur et son mot de passe respectif seront sauvegardés, le prototype ne vérifie pas la validité du courriel, téléphone, etc.*

À chaque fois que vous exécuter le programme,
1. S'inscrire à la page Sign In en tant que résident ou consommateur
2. Entrer vos informations:
    1. **Important:** VOTRE MOT DE PASSE DOIT CONTENIR DES *LETTRES* **ET** DES *CHIFFRES*
    Non valide:
        ![](images\notAccepted.jpg)
        ![](images\notAccepted(1).jpg)
        ![](images\notAccepted(2).jpg)
    Valide:
        ![](images\accepted.jpg)
3. Se connecter avec le ***même*** nom d'utilisateur et mot de passe
4. Choisir les options menus.
    1. **Important:** Seulement un template des pages sera affiché. ****Aucun remplissage à faire.**** Vous pouvez seulement aller vers différente page du menu.
5. *Quitter le programme en appuyer 99*.

---
## Auteurs

Kim Trinh (20215539)
Xavier Laperriere (20157146)
Eed Flory Jean-Baptiste (20168335)
Miliya Ai (20180783)





